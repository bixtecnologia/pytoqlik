# pytoqlik

This lib allows you to integrate qlik with jupyter notebook. You can:

1. Open an app inside the jupyter
2. Create a qlik app with data from a pandas dataframe
3. Get data from a qlik object and create a pandas data frame

Essa lib permite integrar o qlik junto do jupyter notebook. You can:
1. Abrir um app dentro do jupyter
2. Criar um app do qlik com os dados de um pandas dataframe
3. Pegar os dados de um objeto do qlik e criar um pandas data frame
